<!-- TODO: Document project setup, architecture, and team workflow. -->
