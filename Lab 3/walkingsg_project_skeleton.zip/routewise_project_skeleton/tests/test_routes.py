# TODO: Add tests for route generation and ranking.
