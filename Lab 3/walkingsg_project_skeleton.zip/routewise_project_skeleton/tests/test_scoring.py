# TODO: Add unit tests for each route-scoring strategy.
