# TODO: Add tests for registration, login, password reset, and authorization.
