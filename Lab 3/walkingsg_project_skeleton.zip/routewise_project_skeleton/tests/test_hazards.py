# TODO: Add tests for hazard reporting and geographic retrieval.
