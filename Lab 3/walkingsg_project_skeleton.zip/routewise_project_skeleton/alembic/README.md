<!-- TODO: Document database migration workflow. -->
