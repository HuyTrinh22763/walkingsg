# TODO: Model credential-related persistence if kept separate from User.
