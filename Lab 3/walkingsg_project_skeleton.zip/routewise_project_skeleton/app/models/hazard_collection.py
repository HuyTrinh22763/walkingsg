# TODO: Model grouped hazard results for geographic queries.
