# TODO: Model collections of routes returned by a search.
