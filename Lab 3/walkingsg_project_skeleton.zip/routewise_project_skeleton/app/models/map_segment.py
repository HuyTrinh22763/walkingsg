# TODO: Model route/map segments and relevant accessibility or shade attributes.
