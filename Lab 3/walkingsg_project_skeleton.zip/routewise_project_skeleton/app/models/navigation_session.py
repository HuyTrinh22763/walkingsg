# TODO: Model active or historical navigation sessions.
