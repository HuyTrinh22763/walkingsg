# TODO: Model reported hazards, locations, types, status, and timestamps.
