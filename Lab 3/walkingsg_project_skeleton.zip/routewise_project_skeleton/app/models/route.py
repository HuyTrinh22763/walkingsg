# TODO: Model candidate and saved routes, including geometry and route metrics.
