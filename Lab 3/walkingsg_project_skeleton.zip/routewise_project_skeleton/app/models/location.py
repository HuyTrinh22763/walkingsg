# TODO: Model named or resolved locations.
