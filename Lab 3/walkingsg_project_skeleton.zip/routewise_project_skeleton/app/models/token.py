# TODO: Model token metadata only if persistence is required by the chosen auth design.
