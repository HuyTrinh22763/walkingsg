# TODO: Represent and validate geographic coordinates.
