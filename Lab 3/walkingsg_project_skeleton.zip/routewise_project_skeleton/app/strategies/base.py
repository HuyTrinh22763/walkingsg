# TODO: Define the shared interface for route-scoring strategies.
