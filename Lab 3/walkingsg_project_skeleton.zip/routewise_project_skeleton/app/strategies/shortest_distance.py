# TODO: Score candidate routes by distance.
