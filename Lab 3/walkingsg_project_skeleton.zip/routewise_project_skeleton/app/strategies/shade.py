# TODO: Score candidate routes by shade coverage or shade preference.
