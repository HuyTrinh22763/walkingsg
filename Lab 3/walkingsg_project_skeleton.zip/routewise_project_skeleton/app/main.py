# TODO: Create the FastAPI application and register API routers.
