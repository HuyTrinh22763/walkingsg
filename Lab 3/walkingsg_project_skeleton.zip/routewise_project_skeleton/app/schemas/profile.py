# TODO: Define profile and preference request/response schemas.
