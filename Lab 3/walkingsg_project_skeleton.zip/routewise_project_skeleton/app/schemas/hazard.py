# TODO: Define hazard submission and hazard-query schemas.
