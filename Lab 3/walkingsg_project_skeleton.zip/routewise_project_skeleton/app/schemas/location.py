# TODO: Define location search and coordinate schemas.
