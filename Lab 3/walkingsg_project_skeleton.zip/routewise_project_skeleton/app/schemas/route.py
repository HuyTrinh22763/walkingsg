# TODO: Define route request, result, scoring, and response schemas.
