# TODO: Coordinate retrieval and filtering of nearby hazards.
