# TODO: Coordinate route selection and selected-route validation.
