# TODO: Coordinate navigation sessions and route progress.
