# TODO: Define the map/location-service interface used by application services.
