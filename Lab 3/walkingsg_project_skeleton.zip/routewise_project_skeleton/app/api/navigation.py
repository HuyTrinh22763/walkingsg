# TODO: Define navigation-session and route-progress endpoints.
