# TODO: Define hazard reporting, retrieval, and moderation endpoints.
