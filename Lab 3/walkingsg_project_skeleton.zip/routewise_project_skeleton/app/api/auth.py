# TODO: Define registration, login, logout, and password-reset endpoints.
