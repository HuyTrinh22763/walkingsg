# TODO: Resolve and validate origin and destination locations.
