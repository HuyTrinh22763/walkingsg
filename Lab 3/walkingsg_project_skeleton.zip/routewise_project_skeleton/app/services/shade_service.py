# TODO: Obtain or calculate shade information for candidate routes.
