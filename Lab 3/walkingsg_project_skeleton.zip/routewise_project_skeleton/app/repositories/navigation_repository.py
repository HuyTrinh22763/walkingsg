# TODO: Persist and retrieve navigation sessions.
