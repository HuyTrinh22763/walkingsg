# TODO: Persist hazards and perform nearby/intersection queries.
